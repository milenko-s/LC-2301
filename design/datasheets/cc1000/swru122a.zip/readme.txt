XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X   Artwork and documentation done by: Texas Instruments AS 			 X
X   Company: Texas Instruments Norway	                          		 X
X   Address: Gaustadall�en 21    0349 OSLO                                       X
X                                                                           	 X
X   Phone  : (+47) 22 95 82 15   Fax :  (+47) 22 95 85 46                   	 X
X                                                                           	 X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02570
PCB NAME : CC1100EM PCB Antenna
REVISION: 1.2
DATE: 2007-03-16
MANUFACTURER : 
QUANTITY:   See order (in panel)

Manufacturers marking: Two letter + year + week
The two letter code shall identify the manufaturer and is decided by the manufacturer. 
No logos or other identifyers are allowed.
The marking shall be in silk screen print at secondary side of the PCB, or in solder 
resist if no silk print at secondary side.

FILE: CC1100EM_PCB_Antenna_PCB_1_3.ZIP PACKED WITH WinZIP 

PCB DESCRIPTION:2 LAYER PCB 1.0 MM
		Dimensions in mil (0.001 inch)
                DOUBLE SIDE SOLDER MASK,
                DOUBLE SIDE SILKSCREEN,
                8 MIL MIN TRACE WIDTH AND 8 MIL MIN ISOLATION.
		Dielectric constant for FR4 is 4.5

                 
FILE NAME            				DESCRIPTION                               	FILE TYPE
-----------------------------------------------------------------------------------------------------------
***PCB MANUFACTURING FILES:
L1.SPL               				LAYER 1 COMPONENT SIDE/POSITIV            	EXT. GERBER
L2.SPL              				LAYER 2 SOLDER SIDE/POSITIV               	EXT. GERBER

STOPCOMP.SPL         				SOLDER MASK COMPONENT SIDE/NEGATIVE             EXT. GERBER
STOPSOLD.SPL         				SOLDER MASK SOLDER SIDE/NEGATIVE                EXT. GERBER

SILKCOMP.SPL         				SILKSCREEN COMPONENT SIDE/POSITIVE            	EXT. GERBER
SILKSOLD.SPL					SILKSCREEN SOLDER SIDE/POSITIVE			EXT. GERBER

NCDRILL.SPL          				NC DRILL THROUGH HOLE                     	EXCELLON
NCDRILL.REP					NC DRILL REPORT					ASCII
DRILL.SPL            				DRILL/MECHANICAL DRAWING                  	EXT. GERBER
DRILL.REP					DRILL REPORT					ASCII

EXT_GERBER.USR	     				EXTENDED GERBER APERTURE TABLE 			ASCII
CNC.USR		     				NC DRILL DEVICE FILE				ASCII

							

README.TXT           		THIS FILE     
