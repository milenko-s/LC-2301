XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX													 X                                                                               X
X   Artwork and documentation done by: CHIPCON AS /K.H. Torvmark 		X													 X                                                                               X
X   Company: CHIPCON AS                           		       		X													 X                                                                               X
X   Address: Gaustadall�en 21    0349 OSLO                                      X													 X                                                                               X
X                                                                           	X 
X   Phone  : (+47) 22 95 85 44   Fax :  (+47) 22 95 85 46                   	X													 X                                                                               X
X                                                                           	X 
X   Contact: KARL H. TORVMARK    (22 95 85 47)                            	X													 X                                                                               X
X   EMAIL  : k.h.torvmark@chipcon.no                                           	X													 X                                                                               X 
X                                                                           	X 
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02519
PCB NAME : CC1000PP
REVISION: 3.1
DATE: 2002-03-08
MANUFACTURER : 
QUANTITY:   See order (in panel)

FILE: CC1000PP_3_1.ZIP PACKED WITH WinZIP V.7.0 

PCB DECRIPTION:	2 LAYER PCB 1.6 MM
		Dimensions in mil (0.001 inch)
                DOUBLE SIDES SOLDER MASK,
                SINGLE SIDE SILKSCREEN,
                8 MIL MIN TRACE WIDTH AND 8 MIL MIN ISOLATION.

                 
FILE NAME            	DESCRIPTION                              FILE TYPE
***PCB MANUFACTURING FILES:
L1.SPL               	LAYER 1 COMPONENT SIDE/POSITIV           EXT. GERBER
L2.SPL              	LAYER 2 SOLDER SIDE/POSITIV              EXT. GERBER
STOPCOMP.SPL         	SOLDER MASK COMPONENT SIDE/NEGATIVE      EXT. GERBER
STOPSOLD.SPL         	SOLDER MASK SOLDER SIDE/NEGATIVE         EXT. GERBER
SILKCOMP.SPL         	SILKSCREEN COMPONENT SIDE/POSITIVE       EXT. GERBER
NCDRILL.SPL          	NC DRILL THROUGH HOLE                    EXCELLON
NCDRILL.REP		NC DRILL REPORT				 ASCII
DRILL.SPL            	DRILL/MECHANICAL DRAWING                 EXT. GERBER
DRILL.REP		DRILL REPORT				 ASCII
NOR01.USR	     	EXTENDED GERBER APERTURE TABLE 	         ASCII
CNC.USR		     	NC DRILL DEVICE FILE			 ASCII
README.TXT           	THIS FILE                                ASCII


***PCB ASSEMBLY FILES:
PARTLIST.REP		PART LIST FOR ASSEMBLY			 ASCII
PARTLIST.TXT		PART LIST, edited		  	 ASCII
BOM.REP			BILL OF MATERIALS FOR PURCHASE	     	 ASCII
BOM.TXT			BOM, edited				 ASCII
P&PCOMP.REP		PICK AND PLACE COORDINATES		 ASCII
ASSEMBLY_NOTE.DOC	PICK AND PLACE REFERENCE POINT	     	 WORD
PASTCOMP.SPL         	SOLDER PASTE COMPONENT SIDE              EXT. GERBER
ASSYCOMP.SPL        	ASSEMBLY DRAWING COMPONENT SIDE          EXT. GERBER
SCHEMATIC_P1.PDF	SCHEMATIC FILE				 PDF



***DESIGN FILES:
CC1000PP_1_1.SCM	CADSTAR SCHEMATIC FILE			 BINARY
CC1000PP_2_1.PCB       	CADSTAR WORK FILE  (PCB)                 BINARY
CC1000PP_2_1.CPA       	CADSTAR WORK FILE  (PCB)                 ASCII
CC1000PP_2_1.SET       	CADSTAR ROUTE EDITOR SETTINGS            ASCII
*.COL			COLOR FILES DEFINING PLOTS       	 BINARY


               
END.
